//
//  PhunModel.swift
//  PhunApp
//
//  Created by Hari Kunwar on 11/30/15.
//  Copyright (c) 2015 learning. All rights reserved.
//

import UIKit
import CoreData

class PhunModel: NSManagedObject {
    
}
